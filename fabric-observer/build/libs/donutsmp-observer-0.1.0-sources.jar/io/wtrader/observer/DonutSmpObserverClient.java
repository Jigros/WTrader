package io.wtrader.observer;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import io.wtrader.observer.mixin.HandledScreenAccessor;

public final class DonutSmpObserverClient implements ClientModInitializer {
    private final ObserverTransport transport = new ObserverTransport();
    private String openGuiId;
    private String lastGuiSignature;
    private String lastInventorySignature;

    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> transport.connect());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> transport.emit("client.disconnected", "{\"reason\":\"client_stopping\"}"));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> transport.emit("client.connected", "{}"));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            closeScreen();
            transport.emit("client.disconnected", "{\"reason\":\"server_disconnected\"}");
        });
        ClientTickEvents.END_CLIENT_TICK.register(this::observeClient);
    }

    private void observeClient(class_310 client) {
        transport.connect();
        observeScreen(client.field_1755);
        observeInventory(client);
    }

    private void observeScreen(class_437 screen) {
        if (!(screen instanceof class_465<?> handledScreen)) {
            closeScreen();
            return;
        }
        class_1703 handler = handledScreen.method_17577();
        String guiId = "handled:" + handler.field_7763 + ":" + handledScreen.method_25440().getString();
        String snapshot = guiSnapshot(guiId, handledScreen, handler);
        String signature = sha256(snapshot);
        if (!guiId.equals(openGuiId)) {
            openGuiId = guiId;
            lastGuiSignature = null;
            ScreenMouseEvents.afterMouseClick(handledScreen).register((ignored, mouseX, mouseY, button) -> observeManualClick(handledScreen, mouseX, mouseY));
        }
        if (!signature.equals(lastGuiSignature)) {
            boolean opened = lastGuiSignature == null;
            lastGuiSignature = signature;
            transport.emit(opened ? "gui.opened" : "gui.snapshot", snapshotWithSignature(snapshot, signature));
        }
    }

    private void closeScreen() {
        if (openGuiId != null) {
            transport.emit("gui.closed", "{\"guiId\":" + quote(openGuiId) + "}");
            openGuiId = null;
            lastGuiSignature = null;
        }
    }

    private void observeManualClick(class_465<?> screen, double mouseX, double mouseY) {
        if (openGuiId == null) return;
        class_1735 slot = ((HandledScreenAccessor) screen).wtrader$getSlotAt(mouseX, mouseY);
        if (slot != null && slot.field_7874 >= 0) {
            transport.emit("manual.click", "{\"slot\":" + slot.field_7874 + ",\"guiId\":" + quote(openGuiId) + ",\"guiSignature\":" + quote(lastGuiSignature == null ? "unknown" : lastGuiSignature) + "}");
        }
    }

    private void observeInventory(class_310 client) {
        if (client.field_1724 == null) return;
        List<class_1799> stacks = client.field_1724.method_31548().field_7547;
        StringBuilder entries = new StringBuilder();
        for (int slot = 0; slot < stacks.size(); slot++) {
            class_1799 stack = stacks.get(slot);
            if (stack.method_7960()) continue;
            if (!entries.isEmpty()) entries.append(',');
            entries.append("{\"slot\":").append(slot).append(",\"item\":").append(item(stack)).append('}');
        }
        String payload = "{\"observedAt\":" + quote(java.time.Instant.now().toString()) + ",\"entries\":[" + entries + "]}";
        String signature = sha256(payload);
        if (!signature.equals(lastInventorySignature)) {
            lastInventorySignature = signature;
            transport.emit("inventory.snapshot", payload);
        }
    }

    private static String guiSnapshot(String guiId, class_465<?> screen, class_1703 handler) {
        StringBuilder slots = new StringBuilder();
        for (class_1735 slot : handler.field_7761) {
            if (!slots.isEmpty()) slots.append(',');
            class_1799 stack = slot.method_7677();
            slots.append("{\"slot\":").append(slot.field_7874).append(",\"item\":").append(stack.method_7960() ? "null" : item(stack)).append('}');
        }
        return "{\"id\":" + quote(guiId) + ",\"observedAt\":" + quote(java.time.Instant.now().toString()) + ",\"title\":" + quote(screen.method_25440().getString()) + ",\"slotCount\":" + handler.field_7761.size() + ",\"slots\":[" + slots + "]";
    }

    private static String snapshotWithSignature(String snapshot, String signature) {
        return snapshot + ",\"signature\":" + quote(signature) + "}";
    }

    private static String item(class_1799 stack) {
        return "{\"itemType\":" + quote(String.valueOf(stack.method_7909())) + ",\"displayName\":" + quote(stack.method_7964().getString()) + ",\"quantity\":" + stack.method_7947() + ",\"enchantments\":[]}";
    }

    private static String quote(String value) {
        StringBuilder escaped = new StringBuilder("\"");
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            switch (character) {
                case '\\' -> escaped.append("\\\\");
                case '\"' -> escaped.append("\\\"");
                case '\n' -> escaped.append("\\n");
                case '\r' -> escaped.append("\\r");
                case '\t' -> escaped.append("\\t");
                default -> {
                    if (character < 0x20) escaped.append(String.format("\\u%04x", (int) character));
                    else escaped.append(character);
                }
            }
        }
        return escaped.append('\"').toString();
    }

    private static String sha256(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte valueByte : hash) result.append(String.format("%02x", valueByte));
            return result.toString();
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException(exception);
        }
    }

    private static final class ObserverTransport implements WebSocket.Listener {
        private static final URI BRIDGE_URI = URI.create(System.getProperty("wtrader.bridge.url", "ws://127.0.0.1:32100"));
        private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
        private final ArrayDeque<String> pending = new ArrayDeque<>();
        private WebSocket socket;
        private boolean connecting;
        private long sequence;
        private long lastAttempt;

        synchronized void connect() {
            if (socket != null || connecting || System.currentTimeMillis() - lastAttempt < 2_000) return;
            connecting = true;
            lastAttempt = System.currentTimeMillis();
            WebSocket.Builder builder = client.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(3));
            String token = System.getProperty("wtrader.bridge.token", System.getenv("BRIDGE_TOKEN"));
            if (token != null && !token.isBlank()) builder.header("Authorization", "Bearer " + token);
            builder.buildAsync(BRIDGE_URI, this).whenComplete((connected, error) -> {
                synchronized (this) {
                    connecting = false;
                    if (error == null) {
                        socket = connected;
                        flush();
                    }
                }
            });
        }

        synchronized void emit(String type, String payload) {
            pending.add("{\"protocolVersion\":1,\"type\":" + quote(type) + ",\"sequence\":" + sequence++ + ",\"timestamp\":" + System.currentTimeMillis() + ",\"payload\":" + payload + "}");
            while (pending.size() > 256) pending.removeFirst();
            connect();
            flush();
        }

        private void flush() {
            if (socket == null || pending.isEmpty()) return;
            String frame = pending.removeFirst();
            socket.sendText(frame, true).whenComplete((ignored, error) -> {
                synchronized (this) {
                    if (error != null) {
                        pending.addFirst(frame);
                        socket = null;
                    } else {
                        flush();
                    }
                }
            });
        }

        @Override
        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
            synchronized (this) { socket = null; }
            return CompletableFuture.completedFuture(null);
        }

        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            synchronized (this) { socket = null; }
        }
    }
}
